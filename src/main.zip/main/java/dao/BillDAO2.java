package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.math.RoundingMode;
import model.Bill2;

public class BillDAO2 extends DAO2 {

    public BillDAO2() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * Luu hoa don thanh toan, cap nhat trang thai phieu goi mon, ban an va diem tich luy
     * @param bill doi tuong Bill2 can luu
     * @return thanh cong hay co loi
     */
    public boolean saveBill(Bill2 bill) {
        if (bill == null || bill.getOrderSlip() == null) return false;
        boolean kq = false;

        String sqlFindBill = "SELECT id FROM tblBill2 WHERE tblOrderSlip2_id = ? FOR UPDATE";
        String sqlInsertBill = "INSERT INTO tblBill2(date, totalAmount, discountPercent, status, cashGiven, changeAmount, tblOrderSlip2_id, tblSalesStaff2_id, tblMembershipCard2_id) "
                + "VALUES(?, ?, ?, 'Đã thanh toán', ?, ?, ?, ?, ?)";
        String sqlUpdateBill = "UPDATE tblBill2 SET date = ?, totalAmount = ?, discountPercent = ?, status = 'Đã thanh toán', "
                + "cashGiven = ?, changeAmount = ?, tblSalesStaff2_id = ?, tblMembershipCard2_id = ? WHERE id = ?";
        String sqlGetTable = "SELECT tblTable2_id FROM tblOrderSlip2 WHERE id = ? FOR UPDATE";
        String sqlUpdateOrderSlip = "UPDATE tblOrderSlip2 SET status = 'Đã thanh toán' WHERE id = ?";
        String sqlUpdateTable = "UPDATE tblTable2 SET status = 'Trống' WHERE id = ? AND NOT EXISTS "
                + "(SELECT 1 FROM tblOrderSlip2 WHERE tblTable2_id = ? AND status = 'Đang sử dụng')";
        String sqlUpdatePoint = "UPDATE tblMembershipCard2 SET point = ? WHERE id = ?";

        try {
            this.con.setAutoCommit(false);

            int orderSlipId = bill.getOrderSlip().getId();
            int staffId = (bill.getSalesStaff() != null)
                    ? bill.getSalesStaff().getId()
                    : bill.getOrderSlip().getSalesStaff().getId();

            // 1. Kiem tra hoa don da ton tai hay chua
            int existingBillId = 0;
            PreparedStatement psFind = con.prepareStatement(sqlFindBill);
            psFind.setInt(1, orderSlipId);
            ResultSet rsFind = psFind.executeQuery();
            if (rsFind.next()) {
                existingBillId = rsFind.getInt("id");
            }

            // 2. Them moi hoac cap nhat hoa don
            Timestamp now = new Timestamp(System.currentTimeMillis());
            if (existingBillId == 0) {
                PreparedStatement psInsert = con.prepareStatement(sqlInsertBill);
                psInsert.setTimestamp(1, now);
                psInsert.setBigDecimal(2, bill.getTotalAmount());
                setNullableDecimal(psInsert, 3, bill.getDiscountPercent());
                setNullableDecimal(psInsert, 4, bill.getCashGiven());
                setNullableDecimal(psInsert, 5, bill.getChangeAmount());
                psInsert.setInt(6, orderSlipId);
                psInsert.setInt(7, staffId);
                setMembershipCard(psInsert, 8, bill);
                psInsert.executeUpdate();
            } else {
                PreparedStatement psUpdate = con.prepareStatement(sqlUpdateBill);
                psUpdate.setTimestamp(1, now);
                psUpdate.setBigDecimal(2, bill.getTotalAmount());
                setNullableDecimal(psUpdate, 3, bill.getDiscountPercent());
                setNullableDecimal(psUpdate, 4, bill.getCashGiven());
                setNullableDecimal(psUpdate, 5, bill.getChangeAmount());
                psUpdate.setInt(6, staffId);
                setMembershipCard(psUpdate, 7, bill);
                psUpdate.setInt(8, existingBillId);
                psUpdate.executeUpdate();
            }

            // 3. Lay id ban an tu phieu goi mon
            PreparedStatement psTableId = con.prepareStatement(sqlGetTable);
            psTableId.setInt(1, orderSlipId);
            ResultSet rsTableId = psTableId.executeQuery();
            if (!rsTableId.next()) {
                throw new SQLException("Khong tim thay phieu goi mon: " + orderSlipId);
            }
            int tableId = rsTableId.getInt("tblTable2_id");

            // 4. Cap nhat trang thai phieu goi mon thanh 'Da thanh toan'
            PreparedStatement psOrder = con.prepareStatement(sqlUpdateOrderSlip);
            psOrder.setInt(1, orderSlipId);
            if (psOrder.executeUpdate() != 1) {
                throw new SQLException("Khong cap nhat duoc trang thai phieu goi mon: " + orderSlipId);
            }

            // 5. Cap nhat trang thai ban thanh 'Trong'
            PreparedStatement psTable = con.prepareStatement(sqlUpdateTable);
            psTable.setInt(1, tableId);
            psTable.setInt(2, tableId);
            psTable.executeUpdate();

            // 6. Cong diem tich luy cho the thanh vien (neu co)
            if (bill.getMembershipCard() != null) {
                int addedPoints = bill.getTotalAmount().setScale(0, RoundingMode.HALF_UP).intValue();
                int currentPoints = (bill.getMembershipCard().getPoint() != null)
                        ? bill.getMembershipCard().getPoint() : 0;
                PreparedStatement psPoint = con.prepareStatement(sqlUpdatePoint);
                psPoint.setInt(1, currentPoints + addedPoints);
                psPoint.setInt(2, bill.getMembershipCard().getId());
                if (psPoint.executeUpdate() != 1) {
                    throw new SQLException("Khong cap nhat duoc diem the thanh vien");
                }
            }

            this.con.commit(); // cmt dong nay neu chay che do JUnit test
            kq = true;
        } catch (Exception e) {
            try {
                this.con.rollback(); // cmt dong nay neu chay che do JUnit test
            } catch (Exception ex) {
                kq = false;
                ex.printStackTrace();
            }
            kq = false;
            e.printStackTrace();
        } finally {
            try {
                this.con.setAutoCommit(true); // cmt dong nay neu chay che do JUnit test
            } catch (Exception ex) {
                kq = false;
                ex.printStackTrace();
            }
        }
        return kq;
    }

    private void setMembershipCard(PreparedStatement ps, int index, Bill2 bill) throws SQLException {
        if (bill.getMembershipCard() != null) {
            ps.setInt(index, bill.getMembershipCard().getId());
        } else {
            ps.setNull(index, java.sql.Types.INTEGER);
        }
    }

    private void setNullableDecimal(PreparedStatement ps, int index, BigDecimal value) throws SQLException {
        if (value != null) {
            ps.setBigDecimal(index, value);
        } else {
            ps.setNull(index, java.sql.Types.DECIMAL);
        }
    }
}