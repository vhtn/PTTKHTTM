package model;

import java.io.Serializable;
import java.util.Date;

public class ReservationSlip2 implements Serializable {
    private int id;
    private Date date;
    private String status;
    private String note;

    public ReservationSlip2() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
}